Name: Jason Berry

ID: 5349067

Email: berry487@umn.edu

The lwUmbrella algorithm works, for one, while the pfUmbrella doesn't. I don't know what's incorrect. The variance for 
lwUmbrella is significantly larger than that for pfUmbrella but that doesn't mean much.