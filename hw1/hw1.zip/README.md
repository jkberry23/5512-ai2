Name: Jason Berry

ID: 5349067

Email: berry487@umn.edu

Run code with: python3 GibbsRain.py <num_steps>


