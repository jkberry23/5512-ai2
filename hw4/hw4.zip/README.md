Name: Jason Berry
ID: 5349067
x500: berry487
To run code:
	python3 taxi_sarsa.py <ε: exploration parameter, default = 0.1> <α: learning rate, default = 0.2> <γ: learning rate, default = 0.99>
	python3 taxi_qlearning.py <ε: exploration parameter, default = 0.1> <α: learning rate, default = 0.5> <γ: learning rate, default = 0.92>
	python3 multiagent_learning.py

The reward comparison graphs were generated using the parameters set as default, which I tuned.