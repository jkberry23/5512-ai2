Name: Jason Berry
ID: 5349067
x500: berry487
To run code:
	python3 mdpVI.py <r: reward for non-terminal state> <γ: discount factor>
	python3 mdpPI.py <r: reward for non-terminal state> <γ: discount factor>
	python3 mdpMC.py <r: reward for non-terminal state> <γ: discount factor> <ε: exploration parameter>
		NOTE: this takes a while to run, but I added a progress bar

I collaborated at a high level with Ketan Inampudi